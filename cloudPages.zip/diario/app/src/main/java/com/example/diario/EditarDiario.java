package com.example.diario;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.preference.PreferenceManager;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.diario.db.DbDiario;
import com.example.diario.db.DbHelper;
import com.example.diario.listaDiarios.DiarioData;
import com.example.diario.listaDiarios.DiariosAdapter;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class EditarDiario extends AppCompatActivity {

    private final int GALLERY_CODE = 1000;
    ImageView iDiario;
    DbHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        boolean tema = prefs.getBoolean("tema",true);
        if(tema) {
            setTheme(R.style.Theme_Azul);
        }
        else{
            setTheme(R.style.Theme_Amarillo);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_diario);

        EditText txtTitulo, txtCuerpo;
        iDiario = (ImageView) findViewById(R.id.i_ediario);
        Button bGuardar = (Button) findViewById(R.id.b_eguardar);
        Button bBorrar = (Button) findViewById(R.id.b_eborrar);

        dbHelper = new DbHelper(getApplicationContext());

        Bitmap bmp = BitmapFactory.decodeByteArray(getIntent().getExtras().getByteArray("foto"), 0, getIntent().getExtras().getByteArray("foto").length);
        iDiario.setImageBitmap(Bitmap.createScaledBitmap(bmp, 250, 250, false));

        txtTitulo = (EditText) findViewById(R.id.t_etitulo);
        txtTitulo.setText(getIntent().getExtras().getString("titulo"));
        txtCuerpo = (EditText) findViewById(R.id.t_ecuerpo);
        txtCuerpo.setText(getIntent().getExtras().getString("cuerpo"));



        bGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Si el titulo o el cuerpo no estan vacios
                if(!txtTitulo.getText().toString().equals("") && !txtCuerpo.getText().toString().equals("")) {

                    //Transormamos la imagen en un BLOB
                    byte[] imageInByte = getBytes(iDiario);
                    //Hacemos una instancia nueva de DbDiario
                    DbDiario dbDiario = new DbDiario(EditarDiario.this);
                    //Realizamos el guardadp
                    long id = dbDiario.actualizarDiario(getFecha(), txtTitulo.getText().toString(), txtCuerpo.getText().toString(), imageInByte);
                    //Si la query ha sido exitosa
                    if (id > 0) {
                        //Se guarda el registro
                        Toast.makeText(EditarDiario.this, "REGISTRO GUARDADO", Toast.LENGTH_LONG).show();

                    } else {
                        //Si la query ha fallado por falta de foto
                        Toast.makeText(EditarDiario.this, "DEBE ELEGIR UNA FOTO", Toast.LENGTH_LONG).show();
                    }
                } else {
                    //Si no se ha rellenado el titulo o el cuerpo
                    Toast.makeText(EditarDiario.this, "DEBE LLENAR LOS CAMPOS OBLIGATORIOS", Toast.LENGTH_LONG).show();
                }
            }
        });

        //Acciones que se realizaran cuando se pulsara el boton de borrar
        bBorrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DbDiario dbDiario = new DbDiario(EditarDiario.this);
               //Borramos el dirario
                long id = dbDiario.borrarDiario(getFecha());
                //Si ha sido un exito volvemos a la interfaz de lista de diarios
                if (id > 0) {
                    Intent intent = new Intent(getApplicationContext(), ListaDiarios.class);
                    startActivity(intent);
                    finish();
                }
            }
        });


    }

    //Metodo para obtener la fecha de un diario que facilita la extraccion de los datos en la base de datos
    private String getFecha(){
        return getIntent().getExtras().getString("fecha");
    }


    //Metodo usado para convertir la imagen en un BLOB para guardarla en la base de datos
    //Metodo obtenido de stack overflow : https://stackoverflow.com/questions/37779515/how-can-i-convert-an-imageview-to-byte-array-in-android-studio
    private byte[] getBytes(ImageView imageView) {
        try {
            Bitmap bitmap = ((BitmapDrawable) imageView.getDrawable()).getBitmap();
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
            byte[] bytesData = stream.toByteArray();
            stream.close();
            return bytesData;
        } catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    //Acciones que se realizan cuando queremos ir para atras
    public void onBackPressed() {
        //Creamos una nueva actividad del menu principla
        Intent intent = new Intent(getApplicationContext(),ListaDiarios.class);
        startActivity(intent);
        //Cerramos esta ctividad
        finish();

    }
}