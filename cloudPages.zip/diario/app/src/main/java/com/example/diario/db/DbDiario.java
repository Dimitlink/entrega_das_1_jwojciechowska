package com.example.diario.db;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;



import java.util.ArrayList;

public class DbDiario extends DbHelper {

    Context context;

    //Clase auxiliar para realizar consultas a la base de datos
    //Codigo modificado de https://github.com/CodigosdeProgramacion/Agenda
    public DbDiario(@Nullable Context context) {
        super(context);
        this.context = context;
    }

    //Metodo para la realizacion de la query para la insercion del diario nuevo
    public long insertarContacto(String usuario, String titulo, String cuerpo, byte[] foto) {

        long id = 0;
        //Realizacion de la query
        try {
            DbHelper dbHelper = new DbHelper(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("fecha", new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(new Date()));
            values.put("usuario", usuario);
            values.put("titulo", titulo);
            values.put("foto", foto);
            values.put("cuerpo", cuerpo);

            //Guardado del valor que indica  si la consulta se ha realizado correctamente o no
            id = db.insert(TABLE_DIARIO, null, values);
            db.close();
        } catch (Exception ex) {
            ex.toString();
        }

        return id;
    }
    //Metodo para la realizacion de la query para la actualizacion de un diario existente
    public long actualizarDiario(String fecha, String titulo, String cuerpo, byte[] foto) {

        long resultado = 0;
        //Realizacion de la query
        try {
            DbHelper dbHelper = new DbHelper(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("titulo", titulo);
            values.put("foto", foto);
            values.put("cuerpo", cuerpo);

            //Guardado del valor que indica  si la consulta se ha realizado correctamente o no
            resultado = db.update(TABLE_DIARIO, values, "fecha=?", new String[]{fecha});
            db.close();
        } catch (Exception ex) {
            ex.toString();
        }
        return resultado;
    }
    //Metodo para la realizacion de la query para el borrado de un diario existente
    public long borrarDiario(String fecha) {

        long resultado = 0;
        //Realizacion de la query
        try {

            DbHelper dbHelper = new DbHelper(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            //Guardado del valor que indica  si la consulta se ha realizado correctamente o no
            resultado = db.delete(TABLE_DIARIO,"fecha=?", new String[]{fecha});
            db.close();
        } catch (Exception ex) {
            ex.toString();
        }
        return resultado;
    }
}