package com.example.diario.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

//Clase auxiliar para realizar la conexion entre la base de datos y la aplicacion
//Codigo modificado de https://github.com/CodigosdeProgramacion/Agenda
public class DbHelper extends SQLiteOpenHelper {

    //Declaracion de variables necesarias para el proceso de creacion de conexion entre la base de datos y la aplicacion
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NOMBRE = "diario.db";
    public static final String TABLE_DIARIO = "t_diario";

    public DbHelper(@Nullable Context context) {
        super(context, DATABASE_NOMBRE, null, DATABASE_VERSION);
    }

    //Metodo que crear el esquema relacional de la base de datos
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //El esquema relacional esta compuesto por una unica tabla cuyos atributos se puede ver
        //a continuacion

        sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_DIARIO + "(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "fecha TEXT NOT NULL," +
                "usuario TEXT NOT NULL," +
                "titulo TEXT NOT NULL," +
                "foto TEXT NOT NULL," +
                "cuerpo TEXT NOT NULL)");
    }

    //Metodo que modificar el esquema relacional de una base de datos ya existente
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        sqLiteDatabase.execSQL("DROP TABLE " + TABLE_DIARIO);
        onCreate(sqLiteDatabase);

    }
}