package com.example.diario.listaDiarios;



import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.diario.EditarDiario;
import com.example.diario.ListaDiarios;
import com.example.diario.R;

import java.util.ArrayList;

//Clase auxiliar que se encarga de la creacion de la lista de los diarios
//Codigo modificado de : https://www.youtube.com/watch?v=4WUwnxrSAuU&t=220s&ab_channel=DEVELOPERU

public class DiariosAdapter  extends  RecyclerView.Adapter<DiariosAdapter.ViewHolder>{

    ArrayList<DiarioData> listaDiarios;
    Context context;
    final DiariosAdapter.OnItemClickListener listener;

    //Asignacion de un listener a cada diario
    public interface OnItemClickListener  {

        void onItemClick(DiarioData item);
    }
    public DiariosAdapter(ArrayList<DiarioData> listaDiarios, ListaDiarios activity, OnItemClickListener listener) {
        this.listaDiarios = listaDiarios;
        this.context = activity;
        this.listener = listener;

    }

    //Metodo responsable de crear nuevas instancias de las vistas que se muestran en un RecyclerView
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //Obtencion del layout de la actividad de ListaDiarios
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.item_diario,parent, false);
        //Asignacion de la vista con las CardViews al RecyclerView
        ViewHolder viewHolder = new ViewHolder(view);
        return  viewHolder;

    }
    //Metodo utilizado para asignar información a un elemento de vista del RecyclerView
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        //Obtencion del objeto DiarioData en una cierta posicion
        final DiarioData diarioData = listaDiarios.get(position);

        //Asignacion de la informacion a la CardView
        holder.titulo.setText(diarioData.getTitulo());
        holder.fecha.setText(diarioData.getFecha());
        holder.cuerpo.setText(diarioData.getCuerpo());
        Bitmap bmp = BitmapFactory.decodeByteArray(diarioData.getImagen(), 0, diarioData.getImagen().length);
        holder.fotoDiario.setImageBitmap(Bitmap.createScaledBitmap(bmp, 250, 250, false));

        //Asignacion de listener a la CardView
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Creacion de la actividad EditarDiario
                Intent intent = new Intent(context, EditarDiario.class);
                //Parametros necesarios para cargar un diario para su edicion
                intent.putExtra("fecha", diarioData.getFecha());
                intent.putExtra("titulo", diarioData.getTitulo());
                intent.putExtra("cuerpo", diarioData.getCuerpo());
                intent.putExtra("foto", diarioData.getImagen());
                context.startActivity(intent);

            }
        });
    }

    //Obtiene la cantidad de objetos que se van a anadir a a la lista de diarios
    @Override
    public int getItemCount() {
        return listaDiarios.size();
    }

    //ViewHolder representa cada uno de los elementos de RecyclerView
    public class ViewHolder extends RecyclerView.ViewHolder{
        ImageView fotoDiario;
        TextView titulo,fecha,cuerpo;

        CardView cardView;
        public ViewHolder(@NonNull View itemView) {
            //Se guardan los elementos de la UI de la CardView para posteriormente poder actualizar los valores
            //en el metodo onBindViewHolder
            super(itemView);
            fotoDiario = (ImageView) itemView.findViewById(R.id.i_diario_lista);
            titulo = (TextView) itemView.findViewById(R.id.t_titulo_lista);
            fecha = (TextView) itemView.findViewById(R.id.t_fecha_lista);
            cuerpo = (TextView) itemView.findViewById(R.id.t_cuerpo_lista);
            cardView = (CardView) itemView.findViewById(R.id.cv_diario);
        }

    }
}
