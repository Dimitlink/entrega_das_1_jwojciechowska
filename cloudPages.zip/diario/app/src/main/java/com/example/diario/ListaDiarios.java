package com.example.diario;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.preference.PreferenceManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import com.example.diario.db.DbHelper;
import com.example.diario.listaDiarios.DiarioData;
import com.example.diario.listaDiarios.DiariosAdapter;

import java.util.ArrayList;

public class ListaDiarios extends AppCompatActivity {
    RecyclerView recyclerView;

    CardView cardView;
    DiariosAdapter adapter;
    ArrayList<DiarioData> listaDiariops;
    DbHelper dbHelper;

    //Metodo de creacion de una nueva actividad
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Configuracion de las preferencias del usuario
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        boolean tema = prefs.getBoolean("tema",true);
        //If que sirve para saber que tema prefiere el usuario
        if(tema) {
            setTheme(R.style.Theme_Azul);
        }
        else{
            setTheme(R.style.Theme_Amarillo);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_diarios);

        //Definicion de los elementos de la UI
        recyclerView = (RecyclerView) findViewById(R.id.rv_diarios);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //Recogida de los datos necesarios
        dbHelper = new DbHelper(getApplicationContext());
        consultarListaDiarios();

    }
    //Metodo utilizado para realizar consulta para obtener los datos de los diarios
    //Codigo modificado de https://www.youtube.com/watch?v=qpLDIgjngyA&t=454s&ab_channel=CristianHenao
    private void consultarListaDiarios() {
        listaDiariops = new ArrayList<DiarioData>();

        //Conexion a la base de datos
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        DiarioData diario = new DiarioData();

        //Query
        String[] CAMPOS = {"id", "fecha","titulo", "foto", "cuerpo"};

        Cursor cursor = db.rawQuery("SELECT id, fecha, titulo, foto, cuerpo FROM t_diario ORDER BY fecha DESC",null);

        //Loop sobre el resultado de la query para cargar los datos en la clase DiarioData
        while (cursor.moveToNext()){
            diario = new DiarioData(cursor.getInt(0),cursor.getString(2),cursor.getString(4),cursor.getString(1),cursor.getBlob(3));
            listaDiariops.add(diario);
        }
        cursor.close();
        //Obtencion del adapter de RecyclerView
        adapter = new DiariosAdapter(listaDiariops, this, new DiariosAdapter.OnItemClickListener() {
            //Acciones a realizar cuando se pulsa un CardView
            @Override
            public void onItemClick(DiarioData item) {
                //Pasamos de la CardView a la UI de escritura de diario
                Intent intent = new Intent(getApplicationContext(), EscribirDiario.class);
                startActivity(intent);
                //Terminamos esta actividad
                finish();
            }
        });
        //Asignacion de adapter a la actividad
        recyclerView.setAdapter(adapter);
    }

    //Acciones a realizar cuando se pulsa el boton de atras
    @Override
    public void onBackPressed() {
            //Abrimos una nueva actividad de menu principal
            Intent intent = new Intent(getApplicationContext(), MenuPrincipal.class);
            startActivity(intent);
            //Terminamos esta actividad
            finish();
    }
}