package com.example.diario;



import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.preference.PreferenceManager;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.diario.db.DbDiario;

import java.io.ByteArrayOutputStream;

public class EscribirDiario extends AppCompatActivity {

    //Vairable necesaria para abrir la galeria
    private final int GALLERY_CODE = 1000;
    //Variables empleadas para no perder informacion
    private int presionadoEscritura = 0;
    private int pulsadoAtras = 0;

    //Variables necesarias para el maenjo de las imagenes
    Uri imagen;
    ImageView iDiario;

    //Metodo de creacion de la actividad EscribirDiario
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Configuracion de las preferencias del usuario
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        boolean tema = prefs.getBoolean("tema",true);
        //If que sirve para saber que tema prefiere el usuario
        if(tema) {
            setTheme(R.style.Theme_Azul);
        }
        else{
            setTheme(R.style.Theme_Amarillo);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_escritura_diario);

        //Declaracion de los elementos de la UI
        EditText txtTitulo, txtCuerpo;

        iDiario = (ImageView) findViewById(R.id.i_diario);
        Button bGuardar = (Button) findViewById(R.id.b_guardar);
        Button bSeleccFoto = (Button) findViewById(R.id.b_galeria);

        txtTitulo = (EditText) findViewById(R.id.t_titulo);
        txtCuerpo = (EditText) findViewById(R.id.t_cuerpoDiario);

        //En caso de que se ha girado la pantalla, se ha pausado la aplicacion o se ha recibido una llamada
        if(savedInstanceState != null){
            //Recuperamos los valores de las variables
            imagen = savedInstanceState.getParcelable("imageUri");
            iDiario.setImageURI(imagen);
            presionadoEscritura = savedInstanceState.getInt("pulsado");
            pulsadoAtras = savedInstanceState.getInt("pulsadoAtras");

            //En caso de que estaba creado el dialogo de alerta
            if(pulsadoAtras == 1){
                //Recreamos el dialogo
                crearDialogo();
            }
        }

        //Accion asignada al boton de la opcion de guardar diario
        //Codgio reutilizado de la refrencia 2 de la biblografia
        //Enlace de github : https://github.com/CodigosdeProgramacion/Agenda
        bGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Si el titulo o el cuerpo no estan vacios
            if(!txtTitulo.getText().toString().equals("") && !txtCuerpo.getText().toString().equals("")) {

                //Transormamos la imagen en un BLOB
                byte[] imageInByte = getBytes(iDiario);
                //Hacemos una instancia nueva de DbDiario
                DbDiario dbDiario = new DbDiario(EscribirDiario.this);
                //Realizamos el guardadp
                long id = dbDiario.insertarContacto("Julia", txtTitulo.getText().toString(), txtCuerpo.getText().toString(), imageInByte);

                //Si la query ha sido exitosa
                if (id > 0) {
                    //Se guarda el registro
                    Toast.makeText(EscribirDiario.this, "REGISTRO GUARDADO", Toast.LENGTH_LONG).show();
                    presionadoEscritura = 1;
                    txtTitulo.getText().clear();
                    txtCuerpo.getText().clear();

                    //Creamos una notificacion

                    //Acciones a realizar si la version de sdk es mayor que tiramisu
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.POST_NOTIFICATIONS) !=
                                PackageManager.PERMISSION_GRANTED) {
                            //Pedida de permiso
                            ActivityCompat.requestPermissions(EscribirDiario.this, new
                                    String[]{Manifest.permission.POST_NOTIFICATIONS}, 11);
                        }
                    }
                    NotificationManager elManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    NotificationCompat.Builder elBuilder = new NotificationCompat.Builder(getApplicationContext(), "IdCanal");

                    //Si la version de sdk es mayor que la version oreo
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                        //Creamos el canal de comunicacion
                        NotificationChannel channel = new NotificationChannel("IdCanal", "canal", NotificationManager.IMPORTANCE_DEFAULT);
                        channel.setDescription("Canal");

                        //Creamos la notificacion
                        NotificationManager notificationManager = getSystemService(NotificationManager.class);
                        notificationManager.createNotificationChannel(channel);

                        //Definimos los detalles de la notificacion
                        elBuilder.setSmallIcon(R.drawable.icon)
                                .setContentTitle("¡Enhorabuena!")
                                .setContentText("¡Buen trabajo! Acabas de escribir un diario. Recuerda que plasmar tus emociones ayuda a gestionarlas")
                                .setVibrate(new long[]{0, 1000, 500, 1000})
                                .setAutoCancel(true);

                        //Lanzamos la notificacion
                        elManager.notify(1, elBuilder.build());
                    }
                } else {
                    //Si la query ha fallado por falta de foto
                    Toast.makeText(EscribirDiario.this, "DEBE ELEGIR UNA FOTO", Toast.LENGTH_LONG).show();
                }
            } else {
                //Si no se ha rellenado el titulo o el cuerpo
                Toast.makeText(EscribirDiario.this, "DEBE LLENAR LOS CAMPOS OBLIGATORIOS", Toast.LENGTH_LONG).show();
            }
        }
    });

    ////Accion asignada al boton de seleccion de foto
    bSeleccFoto.setOnClickListener(new View.OnClickListener() {
        @Override
        //Si se ha pulsado el boton
        public void onClick(View view) {
            //Se abre la galeria
            Intent iGaleria = new Intent(Intent.ACTION_PICK);
            iGaleria.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(iGaleria,GALLERY_CODE);
        }
    });

}
    //Metodo usado para convertir la imagen en un BLOB para guardarla en la base de datos
    //Metodo obtenido de stack overflow : https://stackoverflow.com/questions/37779515/how-can-i-convert-an-imageview-to-byte-array-in-android-studio
    private byte[] getBytes(ImageView imageView) {
        try {
            Bitmap bitmap = ((BitmapDrawable) imageView.getDrawable()).getBitmap();
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
            byte[] bytesData = stream.toByteArray();
            stream.close();
            return bytesData;
        } catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    //Metodo que guarda el valor de las variables cuando la actividad pasa a segundo plano o cuando se destruye la actividad
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        //Se guardan los valores de las variables
        outState.putParcelable("imageUri", imagen);
        outState.putInt("pulsado", presionadoEscritura);
        outState.putInt("pulsadoAtras", pulsadoAtras);
    }

    //Metodo para acceder a la galeria de fotos
    //Codigo obtenido de youtube : https://www.youtube.com/watch?v=bLi1qr6h4T4&ab_channel=WsCubeTech
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //Si tenemos acceso
        if(resultCode==RESULT_OK){

            if (requestCode==GALLERY_CODE){

                //Guardamos los dato sde la foto y la insertamos en el ImageView
                iDiario.setImageURI(data.getData());
                imagen = data.getData();


            }
        }
    }
    //Metodo para crear dialogo
    public void crearDialogo(){
        pulsadoAtras = 1;
        //Creamos un dialogo y determinamos sus caracteristicas
        new AlertDialog.Builder(this)
                .setTitle("Aviso")
                .setMessage("¿Seguro que deseas salir sin guardar?")
                .setNegativeButton(android.R.string.no, null)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    //Si no queremos guardar el progreso volvemos al menu principal
                    public void onClick(DialogInterface arg0, int arg1) {
                        Intent intent = new Intent(getApplicationContext(), MenuPrincipal.class);
                        startActivity(intent);
                        presionadoEscritura = 0;
                        finish();
                    }
                }).create().show();
    }

    @Override
    public void onBackPressed() {
        //Si no se ha guardado el diario
        if (presionadoEscritura == 0) {
            //Creamos la alerta
            crearDialogo();
        }
        else{
            //Si se ha guardado el diario volvemos al menu principal
            Intent intent = new Intent(getApplicationContext(), MenuPrincipal.class);
            startActivity(intent);
            presionadoEscritura = 0;
            finish();

        }
    }
}