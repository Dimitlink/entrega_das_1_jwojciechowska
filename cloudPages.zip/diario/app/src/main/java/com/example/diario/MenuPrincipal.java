package com.example.diario;

import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

//Menu principal de la aplicacion
public class MenuPrincipal extends AppCompatActivity {

    Button bEscribir, bLista, bAjustes;

    //Metodo onCreate del menu principal
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Configuracion de las preferencias del usuario
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        boolean tema = prefs.getBoolean("tema",true);
        //If que sirve para saber que tema prefiere el usuario
        if(tema) {
            setTheme(R.style.Theme_Azul);
        }
        else{
            setTheme(R.style.Theme_Amarillo);
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_principal);

        //Declaracion de los elementos de la UI
        ImageView icono = (ImageView) findViewById(R.id.i_icono);
        Glide.with(this).load(R.drawable.icon).into(icono);

        bEscribir = (Button) findViewById(R.id.b_escrbir);
        bLista = (Button) findViewById(R.id.b_lista);
        bAjustes = (Button) findViewById(R.id.b_ajustes);


        //Accion asignada al boton de la opcion de escribir diario
        bEscribir.setOnClickListener(new View.OnClickListener() {
            @Override
            //Si se ha pulsado el boton
            public void onClick(View view) {
                //Creamos una actividad de Escribir Diario nueva
                Intent intentEscrituraDiario = new Intent(getApplicationContext(), EscribirDiario.class);
                startActivity(intentEscrituraDiario);
                //Cerramos esta actividad
                finish();

            }
        });

        //Accion asignada al boton de la opcion de escribir diario
        bLista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Creamos una actividad de Lista de diarios nueva
                Intent intentListaDiarios = new Intent(getApplicationContext(),ListaDiarios.class);
                startActivity(intentListaDiarios);
                //Cerramos esta actividad
                finish();

            }
        });

        //Accion asignada al boton de la opcion de escribir diario
        bAjustes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Creamos una actividad de Ajustes nueva
                Intent intentAjustes = new Intent(getApplicationContext(),Ajustes.class);
                startActivity(intentAjustes);
                //Cerramos esta actividad
                finish();

            }
        });
    }
}



