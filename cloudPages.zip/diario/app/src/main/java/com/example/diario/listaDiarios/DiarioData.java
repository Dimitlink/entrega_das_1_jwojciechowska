package com.example.diario.listaDiarios;

import androidx.cardview.widget.CardView;

import java.io.Serializable;

//Clase auxiliar que contiene los datos que se van a plasmar en la CardView
//Codigo modificado de : https://www.youtube.com/watch?v=4WUwnxrSAuU&t=220s&ab_channel=DEVELOPERU
public class DiarioData implements Serializable {
    private int id;
    private String titulo;
    private String cuerpo;
    private String fecha;
    private byte[] imagen;


    public DiarioData(int id, String titulo, String cuerpo, String fecha, byte[] imagen) {
        //Atributos de un diario
        this.id = id;
        this.titulo = titulo;
        this.cuerpo = cuerpo;
        this.fecha = fecha;
        this.imagen = imagen;
    }

    //Metodos getters y setters generados automaticamente necesarios para la insercion de datos a las CardViews
    public DiarioData(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getCuerpo() {
        return cuerpo;
    }

    public void setCuerpo(String cuerpo) {
        this.cuerpo = cuerpo;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public byte[] getImagen() {
        return imagen;
    }

    public void setImagen(byte[] imagen) {
        this.imagen = imagen;
    }
}
