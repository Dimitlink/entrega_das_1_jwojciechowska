package com.example.diario;

import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Ajustes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Configuracion de las preferencias del usuario
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        boolean tema = prefs.getBoolean("tema",true);
        //If que sirve para saber que tema prefiere el usuario
        if(tema) {
            setTheme(R.style.Theme_Azul);
        }
        else{
            setTheme(R.style.Theme_Amarillo);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajustes);

    }
    @Override
    //Acciones que se realizan cuando queremos ir para atras
    public void onBackPressed() {
        //Creamos una nueva actividad del menu principla
        Intent intent = new Intent(getApplicationContext(),MenuPrincipal.class);
        startActivity(intent);
        //Cerramos esta ctividad
        finish();

    }
}